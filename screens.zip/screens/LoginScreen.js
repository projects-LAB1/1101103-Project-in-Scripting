// 1. หน้าล็อกอิน (LoginScreen.js)
import React, { useState } from 'react';
import { 
  View, Text, TextInput, TouchableOpacity, 
  StyleSheet, Image, Alert, KeyboardAvoidingView, 
  Platform, ScrollView 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const auth = getAuth();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('ข้อผิดพลาด', 'กรุณากรอกอีเมลและรหัสผ่าน');
      return;
    }

    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      // ล็อกอินสำเร็จ Firebase จะเปลี่ยนสถานะและ App.js จะจัดการการนำทาง
    } catch (error) {
      console.error(error);
      Alert.alert(
        'ล็อกอินไม่สำเร็จ', 
        'อีเมลหรือรหัสผ่านไม่ถูกต้อง กรุณาลองอีกครั้ง'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardContainer}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <View style={styles.logoContainer}>
            <Image 
              source={require('../assets/logo.png')} 
              style={styles.logo} 
              resizeMode="contain"
            />
            <Text style={styles.appTitle}>WAKE UP</Text>
            <Text style={styles.appSubtitle}>นาฬิกาปลุกสำหรับคนตื่นยาก</Text>
          </View>
          
          <View style={styles.formContainer}>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>อีเมล</Text>
              <TextInput
                style={styles.input}
                placeholder="อีเมลของคุณ"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
              />
            </View>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>รหัสผ่าน</Text>
              <TextInput
                style={styles.input}
                placeholder="รหัสผ่านของคุณ"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
              />
            </View>
            
            <TouchableOpacity 
              style={styles.loginButton}
              onPress={handleLogin}
              disabled={loading}
            >
              <Text style={styles.loginButtonText}>
                {loading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.forgotButton}
              onPress={() => navigation.navigate('ForgotPassword')}
            >
              <Text style={styles.forgotButtonText}>ลืมรหัสผ่าน?</Text>
            </TouchableOpacity>
            
            <View style={styles.divider}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>หรือ</Text>
              <View style={styles.dividerLine} />
            </View>
            
            <TouchableOpacity 
              style={styles.registerButton}
              onPress={() => navigation.navigate('Register')}
            >
              <Text style={styles.registerButtonText}>สมัครสมาชิก</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  keyboardContainer: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 30,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: 60,
    marginBottom: 40,
  },
  logo: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#4F46E5',
    marginBottom: 5,
  },
  appSubtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  formContainer: {
    paddingHorizontal: 30,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    marginBottom: 8,
    fontSize: 16,
    fontWeight: '500',
    color: '#374151',
  },
  input: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
  },
  loginButton: {
    backgroundColor: '#4F46E5',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  forgotButton: {
    alignItems: 'center',
    marginTop: 15,
    marginBottom: 20,
  },
  forgotButtonText: {
    color: '#4F46E5',
    fontSize: 14,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E5E7EB',
  },
  dividerText: {
    paddingHorizontal: 10,
    color: '#6B7280',
    fontSize: 14,
  },
  registerButton: {
    borderWidth: 1,
    borderColor: '#4F46E5',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  registerButtonText: {
    color: '#4F46E5',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default LoginScreen;

// 2. หน้ารายการนาฬิกาปลุก (AlarmListScreen.js)
import React, { useState, useEffect } from 'react';
import { 
  View, Text, FlatList, StyleSheet, Switch, 
  TouchableOpacity, Alert, ActivityIndicator 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, collection, query, 
  onSnapshot, doc, updateDoc, where 
} from 'firebase/firestore';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { formatAlarmDays, formatTime } from '../utils/helpers';

const AlarmListScreen = ({ navigation }) => {
  const [alarms, setAlarms] = useState([]);
  const [loading, setLoading] = useState(true);
  const auth = getAuth();
  const db = getFirestore();

  useEffect(() => {
    const userId = auth.currentUser?.uid;
    if (!userId) return;

    const alarmsRef = collection(db, 'users', userId, 'alarms');
    const q = query(alarmsRef, where('isDeleted', '!=', true));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const alarmList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })).sort((a, b) => {
        // แปลงเวลาให้เป็นนาที เพื่อเรียงลำดับ
        const timeToMinutes = (time) => {
          const [hours, minutes] = time.split(':').map(Number);
          return hours * 60 + minutes;
        };
        return timeToMinutes(a.time) - timeToMinutes(b.time);
      });
      
      setAlarms(alarmList);
      setLoading(false);
    }, (error) => {
      console.error("Error loading alarms:", error);
      setLoading(false);
      Alert.alert("ข้อผิดพลาด", "ไม่สามารถโหลดรายการนาฬิกาปลุกได้");
    });

    return unsubscribe;
  }, []);

  const toggleAlarmStatus = async (alarm) => {
    try {
      const userId = auth.currentUser?.uid;
      if (!userId) return;

      const alarmRef = doc(db, 'users', userId, 'alarms', alarm.id);
      await updateDoc(alarmRef, {
        isActive: !alarm.isActive
      });
    } catch (error) {
      console.error("Error toggling alarm status:", error);
      Alert.alert("ข้อผิดพลาด", "ไม่สามารถอัพเดตสถานะนาฬิกาปลุกได้");
    }
  };

  const getTaskTypeText = (taskType) => {
    switch (taskType) {
      case 'math':
        return 'แก้โจทย์คณิตศาสตร์';
      case 'photo':
        return 'ถ่ายรูปตามสี';
      case 'random':
        return 'สุ่มโจทย์';
      default:
        return 'ปลุกธรรมดา';
    }
  };

  const renderAlarmItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.alarmItem}
      onPress={() => navigation.navigate('EditAlarm', { alarm: item })}
      activeOpacity={0.7}
    >
      <View style={styles.alarmMainInfo}>
        <Text style={[
          styles.alarmTime, 
          !item.isActive && styles.inactiveText
        ]}>
          {item.time}
        </Text>
        
        <Text style={[
          styles.alarmDays, 
          !item.isActive && styles.inactiveText
        ]}>
          {formatAlarmDays(item.days)}
        </Text>
        
        {item.label && (
          <Text style={styles.alarmLabel}>{item.label}</Text>
        )}
        
        <View style={styles.alarmTypeContainer}>
          <Icon 
            name={
              item.taskType === 'math' ? 'calculator' : 
              item.taskType === 'photo' ? 'camera' : 
              'shuffle-variant'
            } 
            size={14} 
            color="#6B7280" 
            style={styles.alarmTypeIcon}
          />
          <Text style={styles.alarmType}>
            {getTaskTypeText(item.taskType)}
          </Text>
        </View>
      </View>
      
      <View style={styles.alarmControls}>
        <Switch
          value={item.isActive}
          onValueChange={() => toggleAlarmStatus(item)}
          trackColor={{ false: '#D1D5DB', true: '#C7D2FE' }}
          thumbColor={item.isActive ? '#4F46E5' : '#9CA3AF'}
          ios_backgroundColor="#D1D5DB"
        />
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['right', 'left']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>นาฬิกาปลุก</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => navigation.navigate('AddAlarm')}
        >
          <Icon name="plus" size={24} color="#4F46E5" />
        </TouchableOpacity>
      </View>
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4F46E5" />
        </View>
      ) : alarms.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Icon name="alarm-off" size={80} color="#D1D5DB" />
          <Text style={styles.emptyTitle}>ยังไม่มีนาฬิกาปลุก</Text>
          <Text style={styles.emptySubtitle}>
            กดปุ่ม + ด้านบนเพื่อสร้างนาฬิกาปลุกใหม่
          </Text>
          <TouchableOpacity 
            style={styles.emptyButton}
            onPress={() => navigation.navigate('AddAlarm')}
          >
            <Text style={styles.emptyButtonText}>สร้างนาฬิกาปลุกใหม่</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={alarms}
          renderItem={renderAlarmItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
};

const style = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#F9FAFB',
    },
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingHorizontal: 20,
      paddingVertical: 15,
      borderBottomWidth: 1,
      borderBottomColor: '#E5E7EB',
      backgroundColor: 'white',
    },
    headerTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: '#111827',
    },
    addButton: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: '#EEF2FF',
      justifyContent: 'center',
      alignItems: 'center',
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: 30,
    },
    emptyTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: '#111827',
      marginTop: 20,
      marginBottom: 8,
    },
    emptySubtitle: {
      fontSize: 16,
      color: '#6B7280',
      textAlign: 'center',
      marginBottom: 30,
    },
    emptyButton: {
      backgroundColor: '#4F46E5',
      paddingVertical: 12,
      paddingHorizontal: 20,
      borderRadius: 10,
    },
    emptyButtonText: {
      color: 'white',
      fontSize: 16,
      fontWeight: '600',
    },
    listContainer: {
      padding: 16,
    },
    alarmItem: {
      flexDirection: 'row',
      backgroundColor: 'white',
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.05,
      shadowRadius: 3,
      elevation: 2,
    },
    alarmMainInfo: {
      flex: 1,
    },
    alarmTime: {
      fontSize: 24,
      fontWeight: 'bold',
      color: '#111827',
      marginBottom: 4,
    },
    inactiveText: {
      color: '#9CA3AF',
    },
    alarmDays: {
      fontSize: 15,
      color: '#4B5563',
      marginBottom: 8,
    },
    alarmLabel: {
      fontSize: 14,
      color: '#6B7280',
      marginBottom: 6,
    },
    alarmTypeContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#F3F4F6',
      paddingVertical: 4,
      paddingHorizontal: 8,
      borderRadius: 4,
      alignSelf: 'flex-start',
    },
    alarmTypeIcon: {
      marginRight: 4,
    },
    alarmType: {
      fontSize: 12,
      color: '#6B7280',
    },
    alarmControls: {
      justifyContent: 'center',
      paddingLeft: 10,
    }
  });